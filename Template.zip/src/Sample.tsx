import {FlowComponent } from "flow-component-model";

//declare const manywho: IManywho;
declare const manywho: any;

//REPLACES custom-driver

export default class Sample extends FlowComponent {

    constructor(props: any) {
        super(props);
        this.flowMoved = this.flowMoved.bind(this);
    }

    async componentDidMount() {
        //will get this from a component attribute
        await super.componentDidMount();
        (manywho as any).eventManager.addDoneListener(this.flowMoved, this.componentId);
        this.forceUpdate();
    }

    async componentWillUnmount() {
        await super.componentWillUnmount();
        (manywho as any).eventManager.removeDoneListener(this.componentId);
    }

    async flowMoved(xhr: any, request: any) {
        let me: any = this;
        if(xhr.invokeType==="FORWARD") {
            if(this.loadingState !== eLoadingState.ready){
                window.setTimeout(function() {me.flowMoved(xhr, request)},500);
            }
            else {
                
                this.forceUpdate();
            }
        }
        
    }

    render() {
        return (
            <div>
                Hello World
            </div>
        );
    }

}

manywho.component.register('Sample', Sample);